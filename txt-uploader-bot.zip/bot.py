import telebot

API_TOKEN = "YOUR_BOT_TOKEN"  # BotFather પાસેથી ટોકન મૂકો

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(content_types=['document'])
def handle_docs(message):
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)

    with open(message.document.file_name, 'wb') as new_file:
        new_file.write(downloaded_file)

    bot.reply_to(message, "✅ તમારી TXT ફાઇલ સફળતાપૂર્વક સેવ થઈ ગઈ!")

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 TXT અપલોડર બોટમાં સ્વાગત છે!\nમને ફક્ત TXT ફાઇલ મોકલો.")

print("Bot is running...")
bot.infinity_polling()
